sap.ui.define([
	"test/unit/model/formatter",
	"test/unit/model/models"
], function() {
	"use strict";
});